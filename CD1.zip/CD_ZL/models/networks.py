import torch
import torch.nn as nn
from torch.nn import init
import torch.nn.functional as F
from torch.optim import lr_scheduler
import numpy as np
from torchvision.transforms import ToTensor
import functools
from einops import rearrange
import cv2
import models
from models.help_funcs import Transformer, TransformerDecoder, TwoLayerConv2d
from models.ChangeFormer import ChangeFormerV1, ChangeFormerV2, ChangeFormerV3, ChangeFormerV4, ChangeFormerV5, ChangeFormerV6
from models.SiamUnet_diff import SiamUnet_diff
from models.SiamUnet_conc import SiamUnet_conc
from models.Unet import Unet
from models.DTCDSCN import CDNet34
from typing import List, Dict
from sklearn.decomposition import PCA
from scipy import signal


import torchvision.models as models2




device = "cuda" if torch.cuda.is_available() else "cpu"   

###############################################################################
# Helper Functions
###############################################################################

def get_scheduler(optimizer, args):
    """Return a learning rate scheduler

    Parameters:
        optimizer          -- the optimizer of the network
        args (option class) -- stores all the experiment flags; needs to be a subclass of BaseOptions．　
                              opt.lr_policy is the name of learning rate policy: linear | step | plateau | cosine

    For 'linear', we keep the same learning rate for the first <opt.niter> epochs
    and linearly decay the rate to zero over the next <opt.niter_decay> epochs.
    For other schedulers (step, plateau, and cosine), we use the default PyTorch schedulers.
    See https://pytorch.org/docs/stable/optim.html for more details.
    """
    if args.lr_policy == 'linear':
        def lambda_rule(epoch):
            lr_l = 1- epoch/ float(args.max_epochs + 1)
            return lr_l
        scheduler = lr_scheduler.LambdaLR(optimizer, lr_lambda=lambda_rule)
    elif args.lr_policy == 'step':
        step_size = args.max_epochs//3
        # args.lr_decay_iters
        scheduler = lr_scheduler.StepLR(optimizer, step_size=step_size, gamma=0.1)
    else:
        return NotImplementedError('learning rate policy [%s] is not implemented', args.lr_policy)
    return scheduler


class Identity(nn.Module):
    def forward(self, x):
        return x


def get_norm_layer(norm_type='instance'):
    """Return a normalization layer

    Parameters:
        norm_type (str) -- the name of the normalization layer: batch | instance | none

    For BatchNorm, we use learnable affine parameters and track running statistics (mean/stddev).
    For InstanceNorm, we do not use learnable affine parameters. We do not track running statistics.
    """
    if norm_type == 'batch':
        norm_layer = functools.partial(nn.BatchNorm2d, affine=True, track_running_stats=True)
    elif norm_type == 'instance':
        norm_layer = functools.partial(nn.InstanceNorm2d, affine=False, track_running_stats=False)
    elif norm_type == 'none':
        norm_layer = lambda x: Identity()
    else:
        raise NotImplementedError('normalization layer [%s] is not found' % norm_type)
    return norm_layer


def init_weights(net, init_type='normal', init_gain=0.02):
    """Initialize network weights.

    Parameters:
        net (network)   -- network to be initialized
        init_type (str) -- the name of an initialization method: normal | xavier | kaiming | orthogonal
        init_gain (float)    -- scaling factor for normal, xavier and orthogonal.

    We use 'normal' in the original pix2pix and CycleGAN paper. But xavier and kaiming might
    work better for some applications. Feel free to try yourself.
    """
    def init_func(m):  # define the initialization function
        classname = m.__class__.__name__
        if hasattr(m, 'weight') and (classname.find('Conv') != -1 or classname.find('Linear') != -1):
            if init_type == 'normal':
                init.normal_(m.weight.data, 0.0, init_gain)
            elif init_type == 'xavier':
                init.xavier_normal_(m.weight.data, gain=init_gain)
            elif init_type == 'kaiming':
                init.kaiming_normal_(m.weight.data, a=0, mode='fan_in')
            elif init_type == 'orthogonal':
                init.orthogonal_(m.weight.data, gain=init_gain)
            else:
                raise NotImplementedError('initialization method [%s] is not implemented' % init_type)
            if hasattr(m, 'bias') and m.bias is not None:
                init.constant_(m.bias.data, 0.0)
        elif classname.find('BatchNorm2d') != -1:  # BatchNorm Layer's weight is not a matrix; only normal distribution applies.
            init.normal_(m.weight.data, 1.0, init_gain)
            init.constant_(m.bias.data, 0.0)

    print('initialize network with %s' % init_type)
    net.apply(init_func)  # apply the initialization function <init_func>


def init_net(net, init_type='normal', init_gain=0.02, gpu_ids=[]):
    """Initialize a network: 1. register CPU/GPU device (with multi-GPU support); 2. initialize the network weights
    Parameters:
        net (network)      -- the network to be initialized
        init_type (str)    -- the name of an initialization method: normal | xavier | kaiming | orthogonal
        gain (float)       -- scaling factor for normal, xavier and orthogonal.
        gpu_ids (int list) -- which GPUs the network runs on: e.g., 0,1,2

    Return an initialized network.
    """
    if len(gpu_ids) > 0:
        assert(torch.cuda.is_available())
        net.to(gpu_ids[0])
        if len(gpu_ids) > 1:
            net = torch.nn.DataParallel(net, gpu_ids)  # multi-GPUs
    init_weights(net, init_type, init_gain=init_gain)
    return net


def define_G(args, init_type='normal', init_gain=0.02, gpu_ids=[]):
    if args.net_G == 'base_resnet18':
        net = ResNet(input_nc=3, output_nc=2, output_sigmoid=False)

    elif args.net_G == 'base_transformer_pos_s4':
        net = BASE_Transformer(input_nc=3, output_nc=2, token_len=4, resnet_stages_num=4,
                             with_pos='learned')

    elif args.net_G == 'base_transformer_pos_s4_dd8':
        net = BASE_Transformer(input_nc=3, output_nc=2, token_len=4, resnet_stages_num=4,
                             with_pos='learned', enc_depth=1, dec_depth=8)

    elif args.net_G == 'base_transformer_pos_s4_dd8_dedim8':
        net = BASE_Transformer(input_nc=3, output_nc=2, token_len=4, resnet_stages_num=4,
                             with_pos='learned', enc_depth=1, dec_depth=8, decoder_dim_head=8)
        

    elif args.net_G == 'ChangeFormerV1':
        net = ChangeFormerV1() #ChangeFormer with Transformer Encoder and Convolutional Decoder
    
    elif args.net_G == 'ChangeFormerV2':
        net = ChangeFormerV2() #ChangeFormer with Transformer Encoder and Convolutional Decoder

    elif args.net_G == 'ChangeFormerV3':
        net = ChangeFormerV3() #ChangeFormer with Transformer Encoder and Convolutional Decoder (Fuse)

    elif args.net_G == 'ChangeFormerV4':
        net = ChangeFormerV4() #ChangeFormer with Transformer Encoder and Convolutional Decoder (Fuse)
    
    elif args.net_G == 'ChangeFormerV5':
        net = ChangeFormerV5(embed_dim=args.embed_dim) #ChangeFormer with Transformer Encoder and Convolutional Decoder (Fuse)

    elif args.net_G == 'ChangeFormerV6':
        net = ChangeFormerV6(embed_dim=args.embed_dim) #ChangeFormer with Transformer Encoder and Convolutional Decoder (Fuse)
    
    elif args.net_G == "SiamUnet_diff":
        #Implementation of ``Fully convolutional siamese networks for change detection''
        #Code copied from: https://github.com/rcdaudt/fully_convolutional_change_detection
        net = SiamUnet_diff(input_nbr=3, label_nbr=2)

    elif args.net_G == "SiamUnet_conc":
        #Implementation of ``Fully convolutional siamese networks for change detection''
        #Code copied from: https://github.com/rcdaudt/fully_convolutional_change_detection
        net = SiamUnet_conc(input_nbr=3, label_nbr=2)

    elif args.net_G == "Unet":
        #Usually abbreviated as FC-EF = Image Level Concatenation
        #Implementation of ``Fully convolutional siamese networks for change detection''
        #Code copied from: https://github.com/rcdaudt/fully_convolutional_change_detection
        net = Unet(input_nbr=3, label_nbr=2)
    
    elif args.net_G == "DTCDSCN":
        #The implementation of the paper"Building Change Detection for Remote Sensing Images Using a Dual Task Constrained Deep Siamese Convolutional Network Model "
        #Code copied from: https://github.com/fitzpchao/DTCDSCN
        net = CDNet34(in_channels=3)

    else:
        raise NotImplementedError('Generator model name [%s] is not recognized' % args.net_G)
    # 
   
    return init_net(net, init_type, init_gain, gpu_ids)


###############################################################################
# main Functions
###############################################################################


class ResNet(torch.nn.Module):
    def __init__(self, input_nc, output_nc,
                 resnet_stages_num=5, backbone='resnet18',
                 output_sigmoid=False, if_upsample_2x=True):
        """
        In the constructor we instantiate two nn.Linear modules and assign them as
        member variables.
        """
        super(ResNet, self).__init__()
        expand = 1
        if backbone == 'resnet18':
            self.resnet = models.resnet18(pretrained=True,
                                          replace_stride_with_dilation=[False,True,True])
        elif backbone == 'resnet34':
            self.resnet = models.resnet34(pretrained=True,
                                          replace_stride_with_dilation=[False,True,True])
        elif backbone == 'resnet50':
            self.resnet = models.resnet50(pretrained=True,
                                          replace_stride_with_dilation=[False,True,True])
            expand = 4
        else:
            raise NotImplementedError
        self.relu = nn.ReLU()
        self.upsamplex2 = nn.Upsample(scale_factor=2)
        self.upsamplex4 = nn.Upsample(scale_factor=4, mode='bilinear')

        self.classifier = TwoLayerConv2d(in_channels=32, out_channels=output_nc)

        self.resnet_stages_num = resnet_stages_num

        self.if_upsample_2x = if_upsample_2x
        if self.resnet_stages_num == 5:
            layers = 512 * expand
        elif self.resnet_stages_num == 4:
            layers = 256 * expand
        elif self.resnet_stages_num == 3:
            layers = 128 * expand
        else:
            raise NotImplementedError
        self.conv_pred = nn.Conv2d(layers, 32, kernel_size=3, padding=1)

        self.output_sigmoid = output_sigmoid
        self.sigmoid = nn.Sigmoid()

    def forward(self, x1, x2):
        x1 = self.forward_single(x1)
        x2 = self.forward_single(x2)
        x = torch.abs(x1 - x2)
        if not self.if_upsample_2x:
            x = self.upsamplex2(x)
        x = self.upsamplex4(x)
        x = self.classifier(x)

        if self.output_sigmoid:
            x = self.sigmoid(x)
        return x

    def forward_single(self, x):
        # resnet layers
        x = self.resnet.conv1(x)
        x = self.resnet.bn1(x)
        x = self.resnet.relu(x)
        x = self.resnet.maxpool(x)

        x_4 = self.resnet.layer1(x) # 1/4, in=64, out=64
        x_8 = self.resnet.layer2(x_4) # 1/8, in=64, out=128

        if self.resnet_stages_num > 3:
            x_8 = self.resnet.layer3(x_8) # 1/8, in=128, out=256

        if self.resnet_stages_num == 5:
            x_8 = self.resnet.layer4(x_8) # 1/32, in=256, out=512
        elif self.resnet_stages_num > 5:
            raise NotImplementedError

        if self.if_upsample_2x:
            x = self.upsamplex2(x_8)
        else:
            x = x_8
        # output layers
        x = self.conv_pred(x)
        return x



    def forward(self, x):
        x = self.conv1(x)
        x = self.bn1(x)
        x = nn.ReLU(inplace=True)(x)
        x = self.maxpool(x)
        x = self.stage2(x)
        x = self.stage3(x)
        x = self.stage4(x)
        x = self.conv5(x)
        x = self.bn5(x)
        x = nn.ReLU(inplace=True)(x)
        x = self.avgpool(x)
        x = x.view(x.size(0), -1)
        x = self.fc(x)
        return x



        
    def forward_single(self, x):
        # resnet layers
        x = self.resnet.conv1(x)
        x = self.resnet.bn1(x)
        x = self.resnet.relu(x)
        x = self.resnet.maxpool(x)

        x_4 = self.resnet.layer1(x) # 1/4, in=64, out=64
        x_8 = self.resnet.layer2(x_4) # 1/8, in=64, out=128

        if self.resnet_stages_num > 3:
            x_8 = self.resnet.layer3(x_8) # 1/8, in=128, out=256

        if self.resnet_stages_num == 5:
            x_8 = self.resnet.layer4(x_8) # 1/32, in=256, out=512
        elif self.resnet_stages_num > 5:
            raise NotImplementedError

        if self.if_upsample_2x:
            x = self.upsamplex2(x_8)
        else:
            x = x_8
        # output layers
        x = self.conv_pred(x)
        return x 

class FeatureFusionModule(nn.Module):
    def __init__(self, in_channels1, in_channels2, out_channels):
        super(FeatureFusionModule, self).__init__()
        self.conv1 = nn.Conv2d(out_channels+out_channels, out_channels, kernel_size=1, stride=1, padding=0 )
      

    def forward(self, features, classification):

        # Concatenate features and classification result
        fused_features = torch.cat([features, classification], dim=1)

        # Apply convolution layers to fuse the features
        output = self.conv1(fused_features)
        return output



class MultiscaleFeatureExtraction(nn.Module):
    def __init__(self, dim, dropout=0.1):
        super().__init__()
        # 
        self.global_branch = nn.Sequential(
            # 
            nn.Conv2d(dim, dim, kernel_size=7, padding=3, groups=dim),
            nn.Conv2d(dim, dim, kernel_size=1),
            nn.BatchNorm2d(dim),
            nn.ReLU()
        )
        
        # 
        self.local_branch = nn.Sequential(
            nn.Conv2d(dim, dim, kernel_size=3, padding=1, groups=dim),
            nn.Conv2d(dim, dim, kernel_size=1),
            nn.BatchNorm2d(dim),
            #nn.ReLU()
        )
        
        # 
        self.fusion = nn.Sequential(
            nn.Conv2d(dim * 2, dim, kernel_size=1),
            nn.BatchNorm2d(dim),
            #nn.Sigmoid()
        )

    def forward(self, x):
        # 
        global_features = self.global_branch(x)
        # 
        local_features = self.local_branch(x)
        # 
        features = torch.cat([global_features, local_features], dim=1)
        attention = self.fusion(features)
        x_end=x * attention 
        
        return x_end
class TraditionalFeatureExtractor(nn.Module):
    def __init__(self, output_channels=32):
        super().__init__()
        self.output_channels = output_channels
        self.gabor_filters = self._build_gabor_filters()
        
        self.feature_adjust = nn.Sequential(
            nn.Conv2d(31, output_channels, kernel_size=1),
            nn.BatchNorm2d(output_channels),
            nn.ReLU()
        )
        
    def _build_gabor_filters(self):
        filters = []
        ksize = 31
        for theta in np.arange(0, np.pi, np.pi / 4):  # 
            for sigma in [3]:  # 
                for lambd in np.arange(0, np.pi, np.pi / 5):  # 
                    kern = cv2.getGaborKernel((ksize, ksize), sigma, theta, lambd, 0.5, 0, ktype=cv2.CV_32F)
                    filters.append(kern)
        return filters

    def extract_features(self, x):
        device = x.device
        self.to(device)
        
        x_np = x.detach().cpu().numpy()
        batch_size = x_np.shape[0]
        
        # 
        imgs = x_np.transpose(0,2,3,1)
        imgs = (imgs * 255).astype(np.uint8)
        grays = np.stack([cv2.cvtColor(img, cv2.COLOR_RGB2GRAY) for img in imgs]).astype(np.float32) / 255.0

        all_features = []
        for gray in grays:
            # 1. CSM
            cf_features = []
            img_cf = gray.copy()
            # 
            for t in [0.1, 0.2, 0.3, 0.4, 0.5]:
                evolved = self.curvature_flow(img_cf, dt=t)
                dx, dy = np.gradient(evolved)
                cf_features.extend([
                    evolved,  # 
                    np.sqrt(dx**2 + dy**2),  # 
                    np.arctan2(dy, dx)  # 
                ])
            cf_features = np.stack(cf_features)  # 1
            
            # 2.FODM
            frac_features = []
            # four different 
            for alpha in [0.3, 0.5, 0.7, 0.9]:
                fx, fy = self.fractional_differential(gray, alpha)
                magnitude = np.sqrt(fx**2 + fy**2)
                direction = np.arctan2(fy, fx)
                laplacian = self.fractional_laplacian(gray, alpha)
                entropy = np.full_like(magnitude, self.fast_entropy(magnitude))
                
                frac_features.extend([
                    magnitude,  # 
                    direction,  # 
                    laplacian,  # 
                    entropy    # 
                ])
            frac_features = np.stack(frac_features)  # 
            
            # 
            features = np.concatenate([
                cf_features,      # 
                frac_features,    # 
            ], axis=0)
            all_features.append(features)

        features_tensor = torch.from_numpy(np.stack(all_features)).float().to(device)
        return self.feature_adjust(features_tensor)

    def curvature_flow(self, img, dt):
        # 
        if not hasattr(self, 'sobel_x'):
            self.sobel_x = np.array([[-1,0,1],[-2,0,2],[-1,0,1]]) / 8.0
            self.sobel_y = self.sobel_x.T
            
        # 
        dx = signal.convolve2d(img, self.sobel_x, mode='same', boundary='symm')
        dy = signal.convolve2d(img, self.sobel_y, mode='same', boundary='symm')
        
        dxx = signal.convolve2d(dx, self.sobel_x, mode='same', boundary='symm')
        dyy = signal.convolve2d(dy, self.sobel_y, mode='same', boundary='symm')
        
        grad_norm = np.sqrt(dx**2 + dy**2) + 1e-8
        mean_curv = (dxx + dyy) / grad_norm  # 
        
        return img + dt * mean_curv

    def fractional_differential(self, img, alpha):
        r = 3  # 
        w = [1]
        for k in range(1, r+1):
            w.append(-w[-1] * (alpha - k + 1) / k)
        
        result_x = w[0] * img
        result_y = w[0] * img
        
        for k in range(1, r+1):
            result_x += w[k] * (np.roll(img, k, axis=1) - np.roll(img, -k, axis=1)) / 2
            result_y += w[k] * (np.roll(img, k, axis=0) - np.roll(img, -k, axis=0)) / 2
        
        return result_x, result_y

    def fractional_laplacian(self, img, alpha):
        fx, fy = self.fractional_differential(img, alpha/2)
        return fx + fy  # 

    def fast_entropy(self, img, bins=8):
        hist = np.histogram(img, bins=bins, density=True)[0]
        hist = hist[hist > 0]
        return -np.sum(hist * np.log2(hist))
##################ShuffleV2Block#########################zl_idip
# class BASE_Transformer(ResNet):
class BASE_Transformer(ResNet):
    """
    Resnet of 8 downsampling + BIT + bitemporal feature Differencing + a small CNN
    """
    def __init__(self, input_nc, output_nc, with_pos, resnet_stages_num=5,
                 token_len=4, token_trans=True,
                 enc_depth=1, dec_depth=1,
                 dim_head=64, decoder_dim_head=64,
                 tokenizer=True, if_upsample_2x=True,
                 pool_mode='max', pool_size=2,
                 backbone='resnet18',
                 decoder_softmax=True, with_decoder_pos=None,
                 with_decoder=True):
        super(BASE_Transformer, self).__init__(input_nc, output_nc,backbone=backbone,
                                             resnet_stages_num=resnet_stages_num,
                                               if_upsample_2x=if_upsample_2x,
                                               )
        self.token_len = token_len
        self.conv_a = nn.Conv2d(32, self.token_len, kernel_size=1,
                                padding=0, bias=False)
        self.tokenizer = tokenizer
        if not self.tokenizer:
            #  if not use tokenzier，then downsample the feature map into a certain size
            self.pooling_size = pool_size
            self.pool_mode = pool_mode
            self.token_len = self.pooling_size * self.pooling_size

        self.token_trans = token_trans
        self.with_decoder = with_decoder
        dim = 32
        mlp_dim = 2*dim

        self.with_pos = with_pos
        if with_pos == 'learned':
            self.pos_embedding = nn.Parameter(torch.randn(1, self.token_len*2, 32))
        decoder_pos_size = 256//4
        self.with_decoder_pos = with_decoder_pos
        if self.with_decoder_pos == 'learned':
            self.pos_embedding_decoder =nn.Parameter(torch.randn(1, 32,
                                                                 decoder_pos_size,
                                                                 decoder_pos_size))
        self.enc_depth = enc_depth
        self.dec_depth = dec_depth
        self.dim_head = dim_head
        self.decoder_dim_head = decoder_dim_head
        self.transformer = Transformer(dim=dim, depth=self.enc_depth, heads=8,
                                       dim_head=self.dim_head,
                                       mlp_dim=mlp_dim, dropout=0)
        self.transformer_decoder = TransformerDecoder(dim=dim, depth=self.dec_depth,
                            heads=8, dim_head=self.decoder_dim_head, mlp_dim=mlp_dim, dropout=0,
                                                      softmax=decoder_softmax)
        # 
        self.traditional_extractor = TraditionalFeatureExtractor()
        
        # 
        self.feature_fusion = nn.Sequential(
            nn.Conv2d(64, 32, 1),  # 
            nn.BatchNorm2d(32),
            nn.ReLU(),
            nn.Conv2d(32, 32, 3, padding=1),
            nn.BatchNorm2d(32)
        )
        # 
        self.regression_branch = nn.Sequential(
            nn.Conv2d(32, 64, 3, padding=1),
            nn.BatchNorm2d(64),
            nn.ReLU(),
            nn.Conv2d(64, 32, 1),
            nn.BatchNorm2d(32)
        )
    def _forward_semantic_tokens(self, x):
        b, c, h, w = x.shape
        spatial_attention = self.conv_a(x)
        spatial_attention = spatial_attention.view([b, self.token_len, -1]).contiguous()
        spatial_attention = torch.softmax(spatial_attention, dim=-1)
        x = x.view([b, c, -1]).contiguous()
        tokens = torch.einsum('bln,bcn->blc', spatial_attention, x)

        return tokens

    def _forward_reshape_tokens(self, x):
        # b,c,h,w = x.shape
        if self.pool_mode == 'max':
            x = F.adaptive_max_pool2d(x, [self.pooling_size, self.pooling_size])
        elif self.pool_mode == 'ave':
            x = F.adaptive_avg_pool2d(x, [self.pooling_size, self.pooling_size])
        else:
            x = x
        tokens = rearrange(x, 'b c h w -> b (h w) c')
        return tokens

    def _congnitive_attention(self, x):
        if self.with_pos:
            x += self.pos_embedding
        x = self.transformer(x)
        return x

    
    def _forward_transformer_decoder(self, x, m):
        b, c, h, w = x.shape
        if self.with_decoder_pos == 'fix':
            x = x + self.pos_embedding_decoder
        elif self.with_decoder_pos == 'learned':
            x = x + self.pos_embedding_decoder
        
        x = rearrange(x, 'b c h w -> b (h w) c')
        x = self.transformer_decoder(x, m)
        x = rearrange(x, 'b (h w) c -> b c h w', h=h)
        return x  

    def _forward_simple_decoder(self, x, m):
        b, c, h, w = x.shape
        b, l, c = m.shape
        m = m.expand([h,w,b,l,c])
        m = rearrange(m, 'h w b l c -> l b c h w')
        m = m.sum(0)
        x = x + m
        return x    

 

    #     return out
    def forward(self, x1, x2,is_training=True): # test ：is_training=None
        def seg_Neural_scroll_zl(input_data1, input_data2):
            # v4_input
            x1 = self.forward_single(input_data1)
            x2 = self.forward_single(input_data2)
            
            # v1_cal
            trad_feat1 = self.traditional_extractor.extract_features(input_data1)
            trad_feat1 = F.interpolate(trad_feat1, size=(64, 64), mode='bilinear', align_corners=True)
                
            trad_feat2 = self.traditional_extractor.extract_features(input_data2)
            trad_feat2 = F.interpolate(trad_feat2 , size=(64, 64), mode='bilinear', align_corners=True)
            
            #v1_pre
            pred_1 = self.regression_branch(x1)
            pred_2 = self.regression_branch(x2)
            
            # v2
            regression_loss = F.mse_loss(pred_1, trad_feat1) + F.mse_loss(pred_2, trad_feat2)
            
            if self.tokenizer:
                token1 = self._forward_semantic_tokens(x1)
                token2 = self._forward_semantic_tokens(x2)
            else:
                token1 = self._forward_reshape_tokens(x1)
                token2 = self._forward_reshape_tokens(x2)
     
            if self.token_trans:
                self.tokens_ = torch.cat([token1, token2], dim=1)
                self.tokens = self._congnitive_attention(self.tokens_)
                token1, token2 = self.tokens.chunk(2, dim=1)
                
            # fusion
            x1_enhanced = torch.cat([x1, trad_feat1], dim=1)
            x2_enhanced = torch.cat([x2, trad_feat2], dim=1)
            
            x1_fused = self.feature_fusion(x1_enhanced)
            x2_fused = self.feature_fusion(x2_enhanced)
            
            if self.with_decoder:
                x1 = self._forward_transformer_decoder(x1_fused, token1)
                x2 = self._forward_transformer_decoder(x2_fused, token2)
            else:
                x1 = self._forward_simple_decoder(x1_fused, token1)
                x2 = self._forward_simple_decoder(x2_fused, token2)
            feature3 = torch.abs(x1- x2)
            
            if not self.if_upsample_2x:
                feature3 = self.upsamplex2(feature3)
            feature3 = self.upsamplex4(feature3)
            feature3 = self.classifier(feature3)
            
            return feature3, regression_loss
        #out    
        x, regression_loss = seg_Neural_scroll_zl(x1, x2)
       
        
        if self.output_sigmoid:
            x = self.sigmoid(x)
        
                     # Have a nice day
        if is_training:
        # # 
            outputs = []
            outputs.append(x)
            outputs.append(regression_loss)   
            return outputs     
        else:
            # 
            outputs = []
            outputs.append(x)
            return outputs      
 # Shoot me an email if you have any questions!
 # Have a nice day