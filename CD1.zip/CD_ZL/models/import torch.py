import torch
import torch.nn as nn
from torch.nn import init
import torch.nn.functional as F
from torch.optim import lr_scheduler
import numpy as np
from torchvision.transforms import ToTensor
import functools
from einops import rearrange
import cv2




import torchvision.models as models2

class Neural_scroll_zl(nn.Module):
    def __init__(self, feature_dims=3, num_classes=3):
        super(Neural_scroll_zl, self).__init__()

        # 定义输入特征图通道数调整层
        self.input_adjust1 = nn.Conv2d(8, feature_dims[0], kernel_size=1, stride=1, padding=0)
        self.input_adjust2 = nn.Conv2d(8, feature_dims[1], kernel_size=1, stride=1, padding=0)
        self.input_adjust3 = nn.Conv2d(8, feature_dims[2], kernel_size=1, stride=1, padding=0)

        # 解决SSL证书问题
        import ssl
        ssl._create_default_https_context = ssl._create_unverified_context

        # 定义第一个特征图的后端特征提取器
        self.backbone1 = models2.detection.fasterrcnn_resnet50_fpn(pretrained=False, num_classes=num_classes)
        self.backbone1.backbone.conv1 = nn.Identity()  # 用身份函数替换conv1层

        # 定义第二个特征图的后端特征提取器
        self.backbone2 = models2.detection.fasterrcnn_resnet50_fpn(pretrained=False, num_classes=num_classes)
        self.backbone2.backbone.conv1 = nn.Conv2d(feature_dims[1], 64, kernel_size=7, stride=2, padding=3, bias=False)
        self.backbone2.backbone.bn1 = nn.Identity()  # 用身份函数替换第一个BatchNorm层

        # 定义融合三个特征图的卷积层
        self.fusion_layer = nn.Conv2d(feature_dims[0] + feature_dims[1] + feature_dims[2], feature_dims[0], kernel_size=1, stride=1, padding=0)

        # 定义RPN和分类器模块
        self.rpn = self.backbone1.rpn
        self.classifier = self.backbone1.roi_heads.box_predictor

    def forward(self, input):
        feature1, feature2, feature3 = input
        # 通过第一个后端进行前向传递
        output1 = self.backbone1(feature1)

        # 通过第二个后端进行前向传递
        output2 = self.backbone2(feature2)

        # 将三个特征图在通道维度上拼接
        output = torch.cat([output1['tensors'], output2['tensors'], feature3], dim=1)

        # 使用卷积层融合三个特征图
        output = self.fusion_layer(output)

        # 通过RPN和分类器模块进行前向传递
        rpn_output = self.rpn(output)
        classifier_output = self.classifier(output, rpn_output)

        # 提取预测边界框和类标签
        boxes = classifier_output[0]['boxes'].detach().cpu().numpy()
        labels = classifier_output[0]['labels'].detach().cpu().numpy()

        return boxes, labels

# 创建模型实例并运行
model = Neural_scroll_zl()

# 生成随机输入数据
feature1 = torch.randn(1, 8, 32, 64, 64)
feature2 = torch.randn(1, 8, 32, 64, 64)
feature3 = torch.randn(1, 8, 32, 64, 64)
inputs = (feature1, feature2, feature3)

# 前向传播
boxes, labels = model(inputs)

print("Predicted bounding boxes:", boxes)
print("Predicted labels:", labels)
        

